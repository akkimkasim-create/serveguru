// LocalStorage Data Initialization Engine
const initialProducts = [
    { id: "1", name: "Usha Janome Dream Stitch", brand: "Usha", price: 14500, category: "Domestic", description: "Automatic zig-zag sewing machine with 7 built-in stitches and 14 applications.", image: "https://images.unsplash.com/photo-1605367800977-cb0208160911?auto=format&fit=crop&q=80&w=400" },
    { id: "2", name: "Singer Promise 1408", brand: "Singer", price: 12800, category: "Domestic", description: "Perfect beginner domestic sewing machine with 8 built-in stitches.", image: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=400" },
    { id: "3", name: "Jack F4 Direct Drive", brand: "Jack", price: 28500, category: "Industrial", description: "Smart lockstitch industrial machine with power saving motor and speed control.", image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=400" },
    { id: "4", name: "Juki DDL-8700", brand: "Juki", price: 34000, category: "Industrial", description: "High-speed single needle lockstitch industrial machine engineered for heavy performance.", image: "https://images.unsplash.com/photo-1517142089942-ba376ce32a2e?auto=format&fit=crop&q=80&w=400" }
];

const initialServices = [
    { id: "1", title: "Domestic Machine General Service", type: "Domestic", price: "₹650", description: "Complete oiling, timing correction, loop cleaning, and stitch balance assessment." },
    { id: "2", title: "Industrial Overlock / Lockstitch Setup", type: "Industrial", price: "₹1500", description: "High-precision mechanical timing synchronization, direct drive motor diagnostic, alignment setup." }
];

const initialPageContent = {
    heroTitle: "Premium Sewing Machines Sales & Services",
    heroSubtitle: "Authorized dealers for Singer, Usha, Jack, Juki & more. Experience high-quality stitch production with expert Coimbatore technicians.",
    aboutText: "Established in Coimbatore, Bharat Trading Corporation has been the foundation of sewing solutions across Tamil Nadu for years. We specialize in both high-capacity industrial systems and customizable household machinery."
};

if (!localStorage.getItem('btc_products')) {
    localStorage.setItem('btc_products', JSON.stringify(initialProducts));
}
if (!localStorage.getItem('btc_services')) {
    localStorage.setItem('btc_services', JSON.stringify(initialServices));
}
if (!localStorage.getItem('btc_pages')) {
    localStorage.setItem('btc_pages', JSON.stringify(initialPageContent));
}
if (!localStorage.getItem('btc_appointments')) {
    localStorage.setItem('btc_appointments', JSON.stringify([]));
}