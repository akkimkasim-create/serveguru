document.addEventListener("DOMContentLoaded", () => {
    const cForm = document.getElementById('contact-form');
    cForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Thank you for contacting Bharat Trading Corporation. Your inquiry packet has been cached for dispatch management.');
        cForm.reset();
    });
});