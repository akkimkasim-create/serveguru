document.addEventListener("DOMContentLoaded", () => {
    const slotGrid = document.getElementById('slot-grid');
    const form = document.getElementById('appointment-form');
    const slots = ["9–10 AM", "10:30–11:30 AM", "12–1 PM", "1:30–2:30 PM", "3–4 PM", "4:30–5:30 PM"];
    let selectedSlot = "";

    if (slotGrid) {
        slotGrid.innerHTML = slots.map(slot => `
            <div class="slot-option" data-slot="${slot}">${slot}</div>
        `).join('');

        slotGrid.addEventListener('click', (e) => {
            if (e.target.classList.contains('slot-option')) {
                document.querySelectorAll('.slot-option').forEach(el => el.classList.remove('selected'));
                e.target.classList.add('selected');
                selectedSlot = e.target.dataset.slot;
            }
        });
    }

    form?.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!selectedSlot) {
            alert('Please select a valid time slot configuration for inspection.');
            return;
        }

        const appt = {
            id: 'APT' + Date.now(),
            name: document.getElementById('customer-name').value,
            phone: document.getElementById('customer-phone').value,
            date: document.getElementById('service-date').value,
            machine: document.getElementById('machine-model').value,
            slot: selectedSlot,
            status: 'Pending Review'
        };

        const current = getAppointments();
        current.push(appt);
        saveAppointments(current);

        alert(`Appointment submitted successfully for ${appt.date} at ${appt.slot}. Booking ID: ${appt.id}`);
        form.reset();
        document.querySelectorAll('.slot-option').forEach(el => el.classList.remove('selected'));
        selectedSlot = "";
    });
});