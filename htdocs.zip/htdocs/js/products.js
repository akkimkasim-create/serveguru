document.addEventListener("DOMContentLoaded", () => {
    const productGrid = document.getElementById('product-grid');
    const searchInput = document.getElementById('search-products');
    const sortSelect = document.getElementById('sort-products');
    const brandFilters = document.querySelectorAll('.brand-filter');
    const catFilters = document.querySelectorAll('.cat-filter');

    let allProducts = getProducts();

    function renderCatalog() {
        let filtered = [...allProducts];

        // Search text matching
        const searchVal = searchInput?.value.toLowerCase() || '';
        if(searchVal) {
            filtered = filtered.filter(p => p.name.toLowerCase().includes(searchVal) || p.brand.toLowerCase().includes(searchVal));
        }

        // Brand checkbox matching
        const checkedBrands = Array.from(brandFilters).filter(cb => cb.checked).map(cb => cb.value);
        if(checkedBrands.length > 0) {
            filtered = filtered.filter(p => checkedBrands.includes(p.brand));
        }

        // Category checkbox matching
        const checkedCats = Array.from(catFilters).filter(cb => cb.checked).map(cb => cb.value);
        if(checkedCats.length > 0) {
            filtered = filtered.filter(p => checkedCats.includes(p.category));
        }

        // Sort Processing
        const sortMode = sortSelect?.value;
        if(sortMode === 'low') filtered.sort((a,b) => a.price - b.price);
        if(sortMode === 'high') filtered.sort((a,b) => b.price - a.price);

        if(filtered.length === 0) {
            productGrid.innerHTML = `<p style="grid-column: 1/-1; text-align:center; padding: 3rem; color: var(--text-muted);">No products match your criteria.</p>`;
            return;
        }

        productGrid.innerHTML = filtered.map(p => `
            <div class="product-card">
                <div class="product-img-wrap">
                    <img src="${p.image}" alt="${p.name}">
                </div>
                <div class="product-info">
                    <span class="product-brand">${p.brand}</span>
                    <h3 class="product-title">${p.name}</h3>
                    <div class="product-price">₹${p.price.toLocaleString('en-IN')}</div>
                    <a href="product-detail.html?id=${p.id}" class="view-btn">View Details</a>
                </div>
            </div>
        `).join('');
    }

    // Attachment of dynamic listeners
    searchInput?.addEventListener('input', renderCatalog);
    sortSelect?.addEventListener('change', renderCatalog);
    brandFilters.forEach(cb => cb.addEventListener('change', renderCatalog));
    catFilters.forEach(cb => cb.addEventListener('change', renderCatalog));

    renderCatalog();
});