document.addEventListener("DOMContentLoaded", () => {
    const rows = document.getElementById('admin-service-rows');
    const form = document.getElementById('admin-service-form');
    if(!rows) return;

    function render() {
        const services = JSON.parse(localStorage.getItem('btc_services')) || [];
        rows.innerHTML = services.map(s => `
            <tr>
                <td><strong>${s.title}</strong></td>
                <td>${s.type}</td>
                <td>${s.price}</td>
                <td><button class="btn-sm btn-danger" onclick="deleteS('${s.id}')">Delete</button></td>
            </tr>
        `).join('');
    }

    form?.addEventListener('submit', (e) => {
        e.preventDefault();
        const services = JSON.parse(localStorage.getItem('btc_services')) || [];
        services.push({
            id: 'SRV' + Date.now(),
            title: document.getElementById('s-title').value,
            type: document.getElementById('s-type').value,
            price: '₹' + document.getElementById('s-price').value,
            description: document.getElementById('s-desc').value
        });
        localStorage.setItem('btc_services', JSON.stringify(services));
        render();
        form.reset();
    });

    window.deleteS = function(id) {
        let services = JSON.parse(localStorage.getItem('btc_services')) || [];
        services = services.filter(s => s.id !== id);
        localStorage.setItem('btc_services', JSON.stringify(services));
        render();
    };

    render();
});