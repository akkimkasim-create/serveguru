// Robust path-agnostic authentication gateway validator
function verifyAuth() {
    const isAuthenticated = sessionStorage.getItem('btc_admin_authenticated') === 'true';
    
    // Checks if the current page filename is the login page
    const isLoginPage = window.location.pathname.includes('admin-login.html') || 
                          window.location.pathname.includes('login.html');

    // If the user isn't logged in and isn't on the login page, redirect them back to log in
    if (!isAuthenticated && !isLoginPage) {
        window.location.href = 'admin-login.html';
    }
}

// Execute authentication tracking immediately across all admin panel templates
verifyAuth();