document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');
    const products = getProducts();
    const product = products.find(p => p.id === productId);

    const container = document.getElementById('detail-container');
    if(!container) return;

    if(!product) {
        container.innerHTML = `<h2>Product catalog item not found.</h2><a href="products.html">Return to Catalog</a>`;
        return;
    }

    container.innerHTML = `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:4rem; margin-top:2rem;">
            <div style="background:#f1f5f9; padding:2rem; border-radius:12px; display:flex; align-items:center; justify-content:center;">
                <img src="${product.image}" alt="${product.name}" style="max-width:100%; height:auto; border-radius:8px;">
            </div>
            <div>
                <span style="text-transform:uppercase; color:var(--accent); font-weight:700; letter-spacing:1px;">${product.brand}</span>
                <h1 style="font-size:2.5rem; color:var(--primary); margin:0.5rem 0 1rem;">${product.name}</h1>
                <p style="font-size:1.1rem; color:var(--text-muted); margin-bottom:2rem;">${product.description}</p>
                <div style="font-size:2.25rem; font-weight:800; color:var(--primary); margin-bottom:2rem;">₹${product.price.toLocaleString('en-IN')}</div>
                
                <div style="border-top:1px solid var(--border); padding-top:2rem;">
                    <button onclick="alert('Order request initialized. Our representative will contact you via phone within 2 hours.')" class="btn btn-primary" style="border:none; cursor:pointer; width:100%; padding:1rem; font-size:1.1rem;">Inquire Purchase / Place Order</button>
                </div>
            </div>
        </div>
    `;
});