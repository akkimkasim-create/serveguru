// Universal shared functions and Layout loaders
document.addEventListener("DOMContentLoaded", () => {
    loadPageContent();
});

function loadPageContent() {
    const pageData = JSON.parse(localStorage.getItem('btc_pages'));
    if (!pageData) return;

    const heroTitle = document.getElementById('dynamic-hero-title');
    const heroSubtitle = document.getElementById('dynamic-hero-subtitle');
    const aboutText = document.getElementById('dynamic-about-text');

    if (heroTitle) heroTitle.innerText = pageData.heroTitle;
    if (heroSubtitle) heroSubtitle.innerText = pageData.heroSubtitle;
    if (aboutText) aboutText.innerText = pageData.aboutText;
}

function getProducts() {
    return JSON.parse(localStorage.getItem('btc_products')) || [];
}

function saveProducts(products) {
    localStorage.setItem('btc_products', JSON.stringify(products));
}

function getAppointments() {
    return JSON.parse(localStorage.getItem('btc_appointments')) || [];
}

function saveAppointments(apps) {
    localStorage.setItem('btc_appointments', JSON.stringify(apps));
}