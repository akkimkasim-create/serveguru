document.addEventListener("DOMContentLoaded", () => {
    const listBody = document.getElementById('admin-product-rows');
    const form = document.getElementById('admin-product-form');
    if(!listBody) return;

    function renderAdminProducts() {
        const products = getProducts();
        listBody.innerHTML = products.map(p => `
            <tr>
                <td><strong>${p.brand}</strong></td>
                <td>${p.name}</td>
                <td>₹${p.price}</td>
                <td>${p.category}</td>
                <td>
                    <button class="btn-sm btn-danger" onclick="deleteProduct('${p.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    form?.addEventListener('submit', (e) => {
        e.preventDefault();
        const products = getProducts();
        const newP = {
            id: 'PROD' + Date.now(),
            name: document.getElementById('p-name').value,
            brand: document.getElementById('p-brand').value,
            price: Number(document.getElementById('p-price').value),
            category: document.getElementById('p-cat').value,
            description: document.getElementById('p-desc').value,
            image: "https://images.unsplash.com/photo-1605367800977-cb0208160911?auto=format&fit=crop&q=80&w=400"
        };
        products.push(newP);
        saveProducts(products);
        renderAdminProducts();
        form.reset();
    });

    window.deleteProduct = function(id) {
        let products = getProducts();
        products = products.filter(p => p.id !== id);
        saveProducts(products);
        renderAdminProducts();
    };

    renderAdminProducts();
});