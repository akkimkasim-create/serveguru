document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('admin-pages-form');
    if(!form) return;

    const data = JSON.parse(localStorage.getItem('btc_pages'));
    document.getElementById('edit-hero-title').value = data.heroTitle;
    document.getElementById('edit-hero-sub').value = data.heroSubtitle;
    document.getElementById('edit-about').value = data.aboutText;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const updated = {
            heroTitle: document.getElementById('edit-hero-title').value,
            heroSubtitle: document.getElementById('edit-hero-sub').value,
            aboutText: document.getElementById('edit-about').value
        };
        localStorage.setItem('btc_pages', JSON.stringify(updated));
        alert('Global core content mapping operationalized updated states.');
    });
});