document.addEventListener("DOMContentLoaded", () => {
    // Dynamic generation of features or product spotlights on landing page
    const spotlightContainer = document.getElementById('product-spotlight');
    if(spotlightContainer) {
        const products = getProducts().slice(0, 3);
        spotlightContainer.innerHTML = products.map(p => `
            <div class="product-card animate-fade-in">
                <div class="product-img-wrap">
                    <img src="${p.image}" alt="${p.name}">
                </div>
                <div class="product-info">
                    <span class="product-brand">${p.brand}</span>
                    <h3 class="product-title">${p.name}</h3>
                    <div class="product-price">₹${p.price.toLocaleString('en-IN')}</div>
                    <a href="product-detail.html?id=${p.id}" class="view-btn">View Product Details</a>
                </div>
            </div>
        `).join('');
    }
});