document.addEventListener("DOMContentLoaded", () => {
    const grid = document.getElementById('services-render-grid');
    if(!grid) return;

    const services = JSON.parse(localStorage.getItem('btc_services')) || [];

    grid.innerHTML = services.map(s => `
        <div class="service-card">
            <div class="service-icon">${s.type === 'Industrial' ? '🏭' : '🏠'}</div>
            <h3>${s.title}</h3>
            <p>${s.description}</p>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="service-meta">${s.type} Division</span>
                <span style="font-weight:700; color:var(--accent); font-size:1.25rem;">Est: ${s.price}</span>
            </div>
            <a href="book-appointment.html" class="btn btn-secondary" style="margin-top:1.5rem; display:block; text-align:center;">Book Dynamic Service Slot</a>
        </div>
    `).join('');
});