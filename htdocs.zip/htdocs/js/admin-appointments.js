document.addEventListener("DOMContentLoaded", () => {
    const rows = document.getElementById('admin-appt-rows');
    if(!rows) return;

    function render() {
        const appts = getAppointments();
        if(appts.length === 0) {
            rows.innerHTML = `<tr><td colspan="6" style="text-align:center;">No scheduled client checkups found.</td></tr>`;
            return;
        }
        rows.innerHTML = appts.map(a => `
            <tr>
                <td>${a.id}</td>
                <td><strong>${a.name}</strong><br><small>${a.phone}</small></td>
                <td>${a.date}</td>
                <td>${a.slot}</td>
                <td>${a.machine}</td>
                <td>
                    <button class="btn-sm btn-edit" onclick="updateStatus('${a.id}', 'Approved')">Approve</button>
                    <button class="btn-sm btn-danger" onclick="updateStatus('${a.id}', 'Cancelled')">Cancel</button>
                </td>
            </tr>
        `).join('');
    }

    window.updateStatus = function(id, status) {
        let appts = getAppointments();
        appts = appts.map(a => a.id === id ? {...a, status: status} : a);
        saveAppointments(appts);
        alert(`Appointment context shifted status to: ${status}`);
        render();
    };

    render();
});